# APEX PERFORMANCE — Portfolio Demo

A fictional premium fitness coaching landing page, built with plain HTML, CSS, and JavaScript. No build tools or paid services required.

## Preview
Open `index.html` in a browser. For a local server, run `python -m http.server 8000` in this folder and visit `http://localhost:8000`.

## Free deployment
### GitHub Pages
1. Create a new public GitHub repository.
2. Upload `index.html`, `styles.css`, and `script.js` to the repository root.
3. Open repository Settings → Pages → Build and deployment → Deploy from a branch.
4. Choose `main` and `/ (root)`, then Save. GitHub provides a public Pages URL.

### Cloudflare Pages
Create a Pages project and upload the folder as static assets using Direct Upload. Set no build command; output is the root folder.

## Before using for a real client
- Replace APEX brand and all fictional text with authorized client details.
- Add real coaching credentials, pricing, program terms, privacy policy and contact information.
- Connect and test an actual booking and enquiry service. The current form does **not** send or save submissions.
- Replace abstract CSS artwork with licensed client imagery if desired.
- Review accessibility, legal requirements, and platform account age/eligibility.

Google Fonts requires an internet connection; fallback system fonts work offline.
